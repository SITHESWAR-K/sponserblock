"use strict";
(() => {
  // src/types.ts
  var DEFAULT_SETTINGS = {
    autoSkipEnabled: true,
    sponsorBlockFallback: true,
    skipSelfPromo: true,
    backendUrl: "https://yayhcowmesmjccjelmuf.supabase.co/functions/v1/analyze-video"
  };
  var DEFAULT_STATS = {
    sponsorsSkipped: 0,
    timeSavedSeconds: 0,
    videosAnalyzedByAi: 0
  };

  // src/background/serviceWorker.ts
  var CLOUD_EDGE_URL = "https://yayhcowmesmjccjelmuf.supabase.co/functions/v1/analyze-video";
  async function getSettings() {
    return new Promise((resolve) => {
      chrome.storage.local.get(["settings"], (res) => {
        resolve({ ...DEFAULT_SETTINGS, ...res?.settings || {} });
      });
    });
  }
  async function getStats() {
    return new Promise((resolve) => {
      chrome.storage.local.get(["stats"], (res) => {
        resolve({ ...DEFAULT_STATS, ...res?.stats || {} });
      });
    });
  }
  async function updateStats(updater) {
    const prev = await getStats();
    const next = updater(prev);
    return new Promise((resolve) => {
      chrome.storage.local.set({ stats: next }, () => resolve());
    });
  }
  async function fetchBackendJson(path, init) {
    const settings = await getSettings();
    const primaryBase = (settings.backendUrl || CLOUD_EDGE_URL).replace(/\/+$/, "");
    const tryFetch = async (baseUrl) => {
      const res = await fetch(`${baseUrl}${path}`, {
        ...init,
        headers: {
          "Content-Type": "application/json",
          ...init?.headers || {}
        }
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(`HTTP ${res.status}: ${text}`);
      }
      return res.json();
    };
    try {
      return await tryFetch(primaryBase);
    } catch (err) {
      if (primaryBase !== CLOUD_EDGE_URL) {
        return await tryFetch(CLOUD_EDGE_URL);
      }
      throw err;
    }
  }
  async function fetchSponsorBlockSegments(videoId) {
    try {
      const categories = encodeURIComponent(JSON.stringify(["sponsor", "selfpromo"]));
      const url = `https://sponsorblock.ajay.app/api/skipSegments?videoID=${encodeURIComponent(
        videoId
      )}&categories=${categories}`;
      const res = await fetch(url);
      if (!res.ok) {
        return [];
      }
      const data = await res.json();
      if (!Array.isArray(data)) return [];
      return data.filter(
        (item) => Array.isArray(item?.segment) && item.segment.length === 2 && Number(item.segment[1]) - Number(item.segment[0]) >= 5
      ).map((item) => ({
        videoId,
        startTime: Math.round(Number(item.segment[0]) * 100) / 100,
        endTime: Math.round(Number(item.segment[1]) * 100) / 100,
        sponsorName: item.category === "selfpromo" ? "Self Promotion" : "Sponsor (Community)",
        category: item.category === "selfpromo" ? "selfpromo" : "sponsor",
        confidence: 0.98,
        reason: "Crowdsourced from SponsorBlock",
        source: "sponsorblock"
      }));
    } catch {
      return [];
    }
  }
  async function handleLookupVideoSegments(videoId) {
    const settings = await getSettings();
    const [supabaseOutcome, sbOutcome] = await Promise.allSettled([
      fetchBackendJson(`/api/segments/${encodeURIComponent(videoId)}`, { method: "GET" }),
      settings.sponsorBlockFallback ? fetchSponsorBlockSegments(videoId) : Promise.resolve([])
    ]);
    const supabaseData = supabaseOutcome.status === "fulfilled" ? supabaseOutcome.value : null;
    const sbSegments = sbOutcome.status === "fulfilled" ? sbOutcome.value : [];
    if (supabaseData?.analyzed && Array.isArray(supabaseData.segments) && supabaseData.segments.length > 0) {
      return {
        needsAnalysis: false,
        source: supabaseData.source || "groq_ai",
        duration: typeof supabaseData.duration === "number" ? supabaseData.duration : void 0,
        segments: supabaseData.segments
      };
    }
    if (sbSegments.length > 0) {
      if (!supabaseData?.analyzed) {
        fetchBackendJson("/api/segments/sync-sponsorblock", {
          method: "POST",
          body: JSON.stringify({
            videoId,
            segments: sbSegments
          })
        }).catch(() => {
        });
      }
      return {
        needsAnalysis: false,
        source: "sponsorblock",
        duration: typeof supabaseData?.duration === "number" ? supabaseData.duration : void 0,
        segments: sbSegments
      };
    }
    if (supabaseData?.analyzed && supabaseData.hasSponsors === false) {
      return {
        needsAnalysis: false,
        source: supabaseData.source || "groq_ai",
        duration: typeof supabaseData.duration === "number" ? supabaseData.duration : void 0,
        segments: []
      };
    }
    return {
      needsAnalysis: true,
      segments: []
    };
  }
  async function injectScriptsIntoTab(tabId) {
    if (!chrome.scripting) return false;
    try {
      await chrome.scripting.insertCSS({
        target: { tabId },
        files: ["playerOverlay.css"]
      }).catch(() => {
      });
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ["pageBridge.js"],
        world: "MAIN"
      });
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ["contentScript.js"],
        world: "ISOLATED"
      });
      return true;
    } catch {
      return false;
    }
  }
  if (typeof chrome !== "undefined" && chrome.runtime?.onInstalled) {
    chrome.runtime.onInstalled.addListener(() => {
      chrome.tabs?.query({ url: ["*://*.youtube.com/*"] }, (tabs) => {
        for (const tab of tabs || []) {
          if (typeof tab.id === "number") {
            injectScriptsIntoTab(tab.id).catch(() => {
            });
          }
        }
      });
    });
  }
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || typeof message.type !== "string") return false;
    if (message.type === "ENSURE_CONTENT_SCRIPT") {
      const tabId = typeof message.tabId === "number" ? message.tabId : typeof sender?.tab?.id === "number" ? sender.tab.id : void 0;
      if (tabId === void 0) {
        sendResponse({ injected: false, error: "Missing tabId" });
        return false;
      }
      injectScriptsIntoTab(tabId).then((injected) => sendResponse({ injected })).catch((err) => sendResponse({ injected: false, error: err?.message }));
      return true;
    }
    if (message.type === "LOOKUP_VIDEO_SEGMENTS") {
      handleLookupVideoSegments(message.videoId).then((res) => sendResponse(res)).catch(
        (err) => sendResponse({
          needsAnalysis: true,
          segments: [],
          error: err?.message
        })
      );
      return true;
    }
    if (message.type === "ANALYZE_VIDEO_CAPTIONS") {
      const payload = message.payload || {};
      fetchBackendJson("/api/analyze", {
        method: "POST",
        body: JSON.stringify(payload)
      }).then(async (res) => {
        await updateStats((prev) => ({
          ...prev,
          videosAnalyzedByAi: prev.videosAnalyzedByAi + 1
        }));
        sendResponse(res);
      }).catch((err) => {
        sendResponse({
          error: err?.message || "Groq AI analysis request failed",
          segments: []
        });
      });
      return true;
    }
    if (message.type === "VOTE_SEGMENT") {
      fetchBackendJson("/api/vote", {
        method: "POST",
        body: JSON.stringify({
          segmentId: message.segmentId,
          vote: message.vote
        })
      }).then((res) => sendResponse(res)).catch((err) => sendResponse({ error: err?.message }));
      return true;
    }
    if (message.type === "RECORD_SKIP_STATS") {
      const saved = Math.max(0, Number(message.savedSeconds) || 0);
      updateStats((prev) => ({
        ...prev,
        sponsorsSkipped: prev.sponsorsSkipped + 1,
        timeSavedSeconds: prev.timeSavedSeconds + saved
      })).then(() => sendResponse({ ok: true }));
      return true;
    }
    return false;
  });
})();
