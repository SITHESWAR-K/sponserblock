"use strict";
(() => {
  // src/types.ts
  var DEFAULT_SETTINGS = {
    autoSkipEnabled: true,
    sponsorBlockFallback: true,
    skipSelfPromo: true,
    backendUrl: "https://yayhcowmesmjccjelmuf.supabase.co/functions/v1/analyze-video"
  };

  // src/content/playerOverlay.ts
  function formatTime(seconds) {
    const s = Math.max(0, Math.floor(seconds));
    const hrs = Math.floor(s / 3600);
    const mins = Math.floor(s % 3600 / 60);
    const secs = s % 60;
    if (hrs > 0) {
      return `${hrs}:${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
    }
    return `${mins}:${String(secs).padStart(2, "0")}`;
  }
  var PlayerOverlayController = class {
    segments = [];
    settings;
    videoDuration = 0;
    dismissedSegmentKeys = /* @__PURE__ */ new Set();
    lastSkipTimestamp = 0;
    activeToastEl = null;
    activeToastTimer = null;
    statusPillEl = null;
    timeUpdateCleanup = null;
    mountRetryTimer = null;
    onUndoSegment;
    onManualSkipSegment;
    onAutoSkipRecorded;
    constructor(params) {
      this.settings = params.settings;
      this.onUndoSegment = params.onUndoSegment;
      this.onManualSkipSegment = params.onManualSkipSegment;
      this.onAutoSkipRecorded = params.onAutoSkipRecorded;
    }
    updateSettings(settings) {
      this.settings = settings;
      this.renderMarkers();
    }
    resetForNewVideo() {
      this.segments = [];
      this.videoDuration = 0;
      this.dismissedSegmentKeys.clear();
      if (this.mountRetryTimer !== null) {
        clearTimeout(this.mountRetryTimer);
        this.mountRetryTimer = null;
      }
      if (this.timeUpdateCleanup) {
        this.timeUpdateCleanup();
        this.timeUpdateCleanup = null;
      }
      this.clearMarkers();
      this.hideToast();
      this.hideStatusPill();
    }
    isAdPlaying() {
      const player = document.getElementById("movie_player");
      if (!player) return false;
      return player.classList.contains("ad-showing") || player.classList.contains("ad-interrupting");
    }
    showStatusPill(text) {
      const player = document.getElementById("movie_player");
      if (!player) return;
      this.hideStatusPill();
      const pill = document.createElement("div");
      pill.className = "ai-sb-status-pill";
      pill.textContent = text;
      player.appendChild(pill);
      this.statusPillEl = pill;
    }
    hideStatusPill() {
      if (this.statusPillEl) {
        this.statusPillEl.remove();
        this.statusPillEl = null;
      }
    }
    setSegments(segments, duration) {
      this.segments = Array.isArray(segments) ? segments : [];
      if (typeof duration === "number" && !Number.isNaN(duration) && duration > 0) {
        this.videoDuration = duration;
      }
      this.mountWithRetry(0);
    }
    mountWithRetry(attempt) {
      if (this.mountRetryTimer !== null) {
        clearTimeout(this.mountRetryTimer);
        this.mountRetryTimer = null;
      }
      const rendered = this.renderMarkers();
      const attached = this.attachVideoListener();
      if ((!rendered || !attached) && this.segments.length > 0 && attempt < 10) {
        this.mountRetryTimer = window.setTimeout(() => {
          this.mountWithRetry(attempt + 1);
        }, 400);
      }
    }
    renderMarkers() {
      this.clearMarkers();
      if (this.segments.length === 0) return true;
      const progressBar = document.querySelector(".ytp-progress-bar");
      const video = document.querySelector("video.html5-main-video");
      if (!progressBar) return false;
      const liveVideoDuration = !this.isAdPlaying() && video && !Number.isNaN(video.duration) && video.duration > 0 ? video.duration : 0;
      const totalDuration = this.videoDuration > 0 ? this.videoDuration : liveVideoDuration;
      if (totalDuration <= 0) return false;
      const container = document.createElement("div");
      container.className = "ai-sb-markers-container";
      for (const seg of this.segments) {
        if (seg.category === "selfpromo" && !this.settings.skipSelfPromo) {
          continue;
        }
        const leftPct = Math.max(0, Math.min(100, seg.startTime / totalDuration * 100));
        const widthPct = Math.max(
          0.5,
          Math.min(100 - leftPct, (seg.endTime - seg.startTime) / totalDuration * 100)
        );
        const marker = document.createElement("div");
        marker.className = `ai-sb-segment-marker ai-sb-category-${seg.category || "sponsor"}`;
        marker.style.left = `${leftPct}%`;
        marker.style.width = `${widthPct}%`;
        marker.title = `${seg.sponsorName || "Sponsor"} (${formatTime(seg.startTime)} \u2013 ${formatTime(seg.endTime)})`;
        container.appendChild(marker);
      }
      progressBar.appendChild(container);
      return true;
    }
    clearMarkers() {
      document.querySelectorAll(".ai-sb-markers-container").forEach((el) => el.remove());
    }
    getSegmentKey(seg) {
      return seg.id || `${seg.startTime.toFixed(1)}-${seg.endTime.toFixed(1)}`;
    }
    attachVideoListener() {
      if (this.timeUpdateCleanup) {
        this.timeUpdateCleanup();
        this.timeUpdateCleanup = null;
      }
      const video = document.querySelector("video.html5-main-video");
      if (!video) return false;
      const onTimeUpdate = () => {
        if (!this.settings.autoSkipEnabled || this.segments.length === 0) return;
        if (video.paused || video.seeking) return;
        if (this.isAdPlaying()) return;
        const now = Date.now();
        if (now - this.lastSkipTimestamp < 1200) return;
        const currentTime = video.currentTime;
        for (const seg of this.segments) {
          if (seg.category === "selfpromo" && !this.settings.skipSelfPromo) {
            continue;
          }
          const key = this.getSegmentKey(seg);
          if (this.dismissedSegmentKeys.has(key)) {
            continue;
          }
          if (currentTime >= seg.startTime && currentTime < seg.endTime - 0.5) {
            const confidence = seg.confidence ?? 0.9;
            if (confidence >= 0.8) {
              this.lastSkipTimestamp = now;
              video.currentTime = seg.endTime;
              this.onAutoSkipRecorded(seg);
              this.showSkippedToast(seg, video);
              break;
            } else if (confidence >= 0.55) {
              this.showManualSkipPrompt(seg, video);
              break;
            }
          }
        }
      };
      const onLoadedMetadata = () => {
        if (!this.isAdPlaying() && video.duration > 0 && !Number.isNaN(video.duration)) {
          this.videoDuration = video.duration;
          this.renderMarkers();
        }
      };
      video.addEventListener("timeupdate", onTimeUpdate);
      video.addEventListener("loadedmetadata", onLoadedMetadata);
      this.timeUpdateCleanup = () => {
        video.removeEventListener("timeupdate", onTimeUpdate);
        video.removeEventListener("loadedmetadata", onLoadedMetadata);
      };
      return true;
    }
    showSkippedToast(seg, video) {
      const player = document.getElementById("movie_player");
      if (!player) return;
      this.hideToast();
      const toast = document.createElement("div");
      toast.className = "ai-sb-toast";
      const badge = document.createElement("span");
      badge.className = "ai-sb-toast-badge";
      badge.textContent = seg.source === "sponsorblock" ? "SB" : "AI SKIP";
      const textWrap = document.createElement("div");
      textWrap.className = "ai-sb-toast-text";
      const title = document.createElement("div");
      title.className = "ai-sb-toast-title";
      title.textContent = `Skipped ${seg.sponsorName || "Sponsor"}`;
      const sub = document.createElement("div");
      sub.className = "ai-sb-toast-sub";
      sub.textContent = `${formatTime(seg.startTime)} \u2192 ${formatTime(seg.endTime)} (${Math.round(
        seg.endTime - seg.startTime
      )}s saved)`;
      textWrap.appendChild(title);
      textWrap.appendChild(sub);
      const undoBtn = document.createElement("button");
      undoBtn.className = "ai-sb-toast-btn";
      undoBtn.textContent = "Undo & Report";
      undoBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        const key = this.getSegmentKey(seg);
        this.dismissedSegmentKeys.add(key);
        video.currentTime = seg.startTime;
        this.onUndoSegment(seg);
        this.hideToast();
      });
      toast.appendChild(badge);
      toast.appendChild(textWrap);
      toast.appendChild(undoBtn);
      player.appendChild(toast);
      this.activeToastEl = toast;
      this.activeToastTimer = window.setTimeout(() => {
        this.hideToast();
      }, 6500);
    }
    showManualSkipPrompt(seg, video) {
      if (this.activeToastEl) return;
      const player = document.getElementById("movie_player");
      if (!player) return;
      const toast = document.createElement("div");
      toast.className = "ai-sb-toast";
      const badge = document.createElement("span");
      badge.className = "ai-sb-toast-badge";
      badge.textContent = "SPONSOR?";
      const textWrap = document.createElement("div");
      textWrap.className = "ai-sb-toast-text";
      const title = document.createElement("div");
      title.className = "ai-sb-toast-title";
      title.textContent = `${seg.sponsorName || "Sponsor"} (${formatTime(seg.startTime)} \u2192 ${formatTime(seg.endTime)})`;
      textWrap.appendChild(title);
      const skipBtn = document.createElement("button");
      skipBtn.className = "ai-sb-toast-btn ai-sb-toast-btn-primary";
      skipBtn.textContent = "\u23ED Skip Sponsor";
      skipBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        this.lastSkipTimestamp = Date.now();
        video.currentTime = seg.endTime;
        this.onManualSkipSegment(seg);
        this.hideToast();
      });
      const dismissBtn = document.createElement("button");
      dismissBtn.className = "ai-sb-toast-btn";
      dismissBtn.textContent = "\u2715";
      dismissBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        this.dismissedSegmentKeys.add(this.getSegmentKey(seg));
        this.hideToast();
      });
      toast.appendChild(badge);
      toast.appendChild(textWrap);
      toast.appendChild(skipBtn);
      toast.appendChild(dismissBtn);
      player.appendChild(toast);
      this.activeToastEl = toast;
      this.activeToastTimer = window.setTimeout(() => {
        this.hideToast();
      }, 8e3);
    }
    hideToast() {
      if (this.activeToastTimer !== null) {
        clearTimeout(this.activeToastTimer);
        this.activeToastTimer = null;
      }
      if (this.activeToastEl) {
        this.activeToastEl.remove();
        this.activeToastEl = null;
      }
    }
  };

  // src/content/contentScript.ts
  var currentVideoId = null;
  var currentVideoStatus = {
    videoId: null,
    status: "idle",
    source: null,
    segments: []
  };
  var currentSettings = { ...DEFAULT_SETTINGS };
  function setVideoStatus(next) {
    currentVideoStatus = next;
    try {
      if (typeof chrome !== "undefined" && chrome.runtime?.sendMessage) {
        const p = chrome.runtime.sendMessage({
          type: "VIDEO_STATUS_CHANGED",
          state: currentVideoStatus
        });
        if (p && typeof p.catch === "function") {
          p.catch(() => {
          });
        }
      }
    } catch {
    }
  }
  var pendingBridgeRequests = /* @__PURE__ */ new Map();
  function onBridgeWindowMessage(event) {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.type !== "AI_SB_VIDEO_DATA_RESULT") return;
    const pending = pendingBridgeRequests.get(data.requestId);
    if (!pending) return;
    pendingBridgeRequests.delete(data.requestId);
    if (data.success && data.payload) {
      pending.resolve(data.payload);
    } else {
      pending.reject(new Error(data.error || "Failed to extract captions from page"));
    }
  }
  function requestVideoDataFromMainWorld(videoId) {
    return new Promise((resolve, reject) => {
      const requestId = `${videoId}_${Date.now()}_${Math.random().toString(36).slice(2)}`;
      const timer = window.setTimeout(() => {
        if (pendingBridgeRequests.has(requestId)) {
          pendingBridgeRequests.delete(requestId);
          reject(new Error("Timed out waiting for YouTube player bridge"));
        }
      }, 12e3);
      pendingBridgeRequests.set(requestId, {
        resolve: (data) => {
          clearTimeout(timer);
          resolve(data);
        },
        reject: (err) => {
          clearTimeout(timer);
          reject(err);
        }
      });
      window.postMessage(
        {
          type: "AI_SB_EXTRACT_VIDEO_DATA",
          videoId,
          requestId
        },
        "*"
      );
    });
  }
  var overlay = new PlayerOverlayController({
    settings: currentSettings,
    onAutoSkipRecorded: (segment) => {
      const savedSec = Math.max(0, Math.round(segment.endTime - segment.startTime));
      chrome.runtime.sendMessage({
        type: "RECORD_SKIP_STATS",
        savedSeconds: savedSec,
        segment
      });
    },
    onManualSkipSegment: (segment) => {
      const savedSec = Math.max(0, Math.round(segment.endTime - segment.startTime));
      chrome.runtime.sendMessage({
        type: "RECORD_SKIP_STATS",
        savedSeconds: savedSec,
        segment
      });
      if (segment.id) {
        chrome.runtime.sendMessage({
          type: "VOTE_SEGMENT",
          segmentId: segment.id,
          vote: "upvote"
        });
      }
    },
    onUndoSegment: (segment) => {
      if (segment.id) {
        chrome.runtime.sendMessage({
          type: "VOTE_SEGMENT",
          segmentId: segment.id,
          vote: "downvote"
        });
      }
    }
  });
  function extractVideoIdFromUrl(urlStr) {
    try {
      const url = new URL(urlStr);
      if (url.pathname === "/watch") {
        return url.searchParams.get("v");
      }
      const shortsMatch = url.pathname.match(/^\/shorts\/([a-zA-Z0-9_-]{5,})/);
      if (shortsMatch) {
        return shortsMatch[1];
      }
      return null;
    } catch {
      return null;
    }
  }
  async function loadSettings() {
    return new Promise((resolve) => {
      if (typeof chrome === "undefined" || !chrome.storage?.local) {
        resolve();
        return;
      }
      chrome.storage.local.get(["settings"], (res) => {
        if (res?.settings) {
          currentSettings = { ...DEFAULT_SETTINGS, ...res.settings };
          overlay.updateSettings(currentSettings);
        }
        resolve();
      });
    });
  }
  var activeProcessSeq = 0;
  async function processVideo(videoId, forceRefresh = false) {
    const seq = ++activeProcessSeq;
    overlay.resetForNewVideo();
    setVideoStatus({
      videoId,
      status: "loading",
      source: null,
      segments: []
    });
    try {
      if (!forceRefresh) {
        const lookupRes = await chrome.runtime.sendMessage({
          type: "LOOKUP_VIDEO_SEGMENTS",
          videoId
        });
        if (seq !== activeProcessSeq || currentVideoId !== videoId) return;
        if (lookupRes && !lookupRes.needsAnalysis) {
          setVideoStatus({
            videoId,
            status: "ready",
            source: lookupRes.source || "supabase",
            segments: lookupRes.segments || []
          });
          overlay.setSegments(lookupRes.segments || [], lookupRes.duration);
          return;
        }
      }
      setVideoStatus({
        ...currentVideoStatus,
        videoId,
        status: "analyzing"
      });
      overlay.showStatusPill("\u{1F9E0} AI Scanning Captions (Qwen 3.8)...");
      await new Promise((r) => setTimeout(r, 600));
      if (seq !== activeProcessSeq || currentVideoId !== videoId) return;
      const extractedData = await requestVideoDataFromMainWorld(videoId);
      if (seq !== activeProcessSeq || currentVideoId !== videoId) return;
      const cueCount = Array.isArray(extractedData.transcript) ? extractedData.transcript.length : 0;
      const analyzeRes = await chrome.runtime.sendMessage({
        type: "ANALYZE_VIDEO_CAPTIONS",
        payload: {
          ...extractedData,
          forceRefresh
        }
      });
      if (seq !== activeProcessSeq || currentVideoId !== videoId) return;
      overlay.hideStatusPill();
      if (analyzeRes?.error) {
        setVideoStatus({
          videoId,
          status: "error",
          source: null,
          segments: [],
          cueCount,
          hasPaidPromotion: extractedData.hasPaidPromotion,
          error: analyzeRes.error
        });
        return;
      }
      const segments = analyzeRes?.segments || [];
      setVideoStatus({
        videoId,
        status: "ready",
        source: analyzeRes?.source || "groq_ai",
        segments,
        cueCount,
        hasPaidPromotion: extractedData.hasPaidPromotion
      });
      overlay.setSegments(segments, extractedData.duration);
    } catch (err) {
      if (seq !== activeProcessSeq || currentVideoId !== videoId) return;
      overlay.hideStatusPill();
      setVideoStatus({
        videoId,
        status: "error",
        source: null,
        segments: [],
        error: err?.message || "Unexpected error processing video"
      });
    }
  }
  function handleNavigation() {
    const newVideoId = extractVideoIdFromUrl(window.location.href);
    if (!newVideoId) {
      activeProcessSeq++;
      currentVideoId = null;
      overlay.resetForNewVideo();
      setVideoStatus({
        videoId: null,
        status: "idle",
        source: null,
        segments: []
      });
      return;
    }
    if (newVideoId !== currentVideoId || currentVideoStatus.status === "idle") {
      currentVideoId = newVideoId;
      processVideo(newVideoId, false);
    }
  }
  function initContentScript() {
    if (typeof window === "undefined") return false;
    if (window.__AI_SB_CS_INITIALIZED__) {
      handleNavigation();
      return false;
    }
    window.__AI_SB_CS_INITIALIZED__ = true;
    window.addEventListener("message", onBridgeWindowMessage);
    if (typeof chrome !== "undefined" && chrome.runtime?.onMessage) {
      chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
        if (!message || typeof message.type !== "string") return false;
        if (message.type === "GET_CURRENT_VIDEO_STATUS") {
          const urlVid = extractVideoIdFromUrl(window.location.href);
          if (urlVid !== currentVideoId || urlVid && currentVideoStatus.status === "idle") {
            handleNavigation();
          }
          sendResponse(currentVideoStatus);
          return false;
        }
        if (message.type === "SEEK_TO_TIME" && typeof message.time === "number") {
          const video = document.querySelector("video.html5-main-video");
          if (video) {
            video.currentTime = message.time;
          }
          sendResponse({ ok: true });
          return false;
        }
        if (message.type === "SETTINGS_UPDATED" && message.settings) {
          currentSettings = { ...DEFAULT_SETTINGS, ...message.settings };
          overlay.updateSettings(currentSettings);
          sendResponse({ ok: true });
          return false;
        }
        if (message.type === "FORCE_REANALYZE") {
          const targetVideoId = extractVideoIdFromUrl(window.location.href) || (typeof message.videoId === "string" ? message.videoId : null) || currentVideoId;
          if (targetVideoId) {
            currentVideoId = targetVideoId;
            processVideo(targetVideoId, true).then(() => {
              sendResponse(currentVideoStatus);
            });
            return true;
          }
          sendResponse({ error: "No active YouTube video" });
          return false;
        }
        return false;
      });
    }
    (async () => {
      await loadSettings();
      handleNavigation();
      window.addEventListener("yt-navigate-finish", handleNavigation);
      window.addEventListener("popstate", handleNavigation);
      let lastHref = window.location.href;
      setInterval(() => {
        if (window.location.href !== lastHref) {
          lastHref = window.location.href;
          handleNavigation();
        }
      }, 1500);
    })();
    return true;
  }
  if (typeof window !== "undefined" && typeof chrome !== "undefined" && chrome.runtime?.id) {
    initContentScript();
  }
})();
